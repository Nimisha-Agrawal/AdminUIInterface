export interface Owner {
  selectedRow: boolean;
  id: string;
  name: string;
  email: string;
  role: string;
  editable: boolean;
}

export interface CheckedStatusType {
  id: boolean;
}
